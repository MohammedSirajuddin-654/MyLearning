package Connection;

import java.sql.DriverManager;
import java.sql.SQLException;

import java.sql.Connection;

public class MyCon {

	public static  Connection  dbcon() throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/resell","root","");
	
	return con;
}
	
}

