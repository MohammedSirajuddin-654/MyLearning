package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Connection.MyCon;

public class Dao {

	//private Connection con;
	
		public int insert(String email,String name,String mobile,String pass) 
		{
			try{

				Connection con=MyCon.dbcon();
			//	String query="INSERT INTO account(name, user, mob, email, pass) VALUES(?,?,?,?,?)";
				PreparedStatement st=con.prepareStatement("INSERT INTO account(email, name, mobile, pass) VALUES(?,?,?,?)");
				st.setString(1,email);
				st.setString(2, name);
				st.setString(3,mobile);
				st.setString(4,pass);
				int i=0;
				i=st.executeUpdate();
				
				//Statement st=con.createStatement();
				
				//Statement sta=(Statement) con.createStatement(); 
			if(i==1)
				return 1;
			return 0;		
			}
			catch(Exception f)
			{
				f.printStackTrace();
			}
			
			return 0;
		}
		
		public int log(String user,String pass)
		{
			try{
				String sql="select * from account where email=? and pass=?";
				Connection con=MyCon.dbcon();
				PreparedStatement st=con.prepareStatement(sql);
				st.setString(1,user);
				st.setString(2,pass);
				ResultSet rs=st.executeQuery();
				if(rs.next())
				{
				
					return 1;
				}
				else{
				
					return 0;
				}
							
			}
			catch(Exception f)
			{
			}	
			
			return 0;	
		}
		
		public boolean post(String imgpath,String type,String title,String brand,String price,String summary,String cond,String Name,String Email,String num,String city) 
		{
			try{
				Connection con=MyCon.dbcon();
				PreparedStatement st=con.prepareStatement("INSERT INTO product(img,type, title, brand, price, summary,cond,Name,Email,num,city) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
				st.setString(1,imgpath);
				st.setString(2,type);
				st.setString(3,title);
				st.setString(4,brand);
				st.setString(5,price);
				st.setString(6,summary);
				st.setString(7,cond);
				st.setString(8,Name);
				st.setString(9,Email);
				st.setString(10,num);
				st.setString(11,city);

			
				
				int i=st.executeUpdate();
			if(i==1)
				return true;
			return false;		
			}
			catch(Exception f)
			{
				f.printStackTrace();
			}
			
			return false;
		}

		
	}
